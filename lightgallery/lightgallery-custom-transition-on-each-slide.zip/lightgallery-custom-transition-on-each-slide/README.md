# lightGallery custom transition on each slide

A Pen created on CodePen.

Original URL: [https://codepen.io/sachinchoolur/pen/qBYoyBd](https://codepen.io/sachinchoolur/pen/qBYoyBd).

Add custom buttons to lightGallery image gallery