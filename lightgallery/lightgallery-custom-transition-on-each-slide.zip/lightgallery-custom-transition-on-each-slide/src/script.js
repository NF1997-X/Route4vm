import lightGallery from "https://cdn.skypack.dev/lightgallery@2.0.0-beta.4";

import lgZoom from "https://cdn.skypack.dev/lightgallery@2.0.0-beta.4/plugins/zoom";

const $galleryContainer = document.getElementById("gallery-container");

const transitions = [
  "lg-slide",
  "lg-fade",
  "lg-zoom-in",
  "lg-zoom-in-big",
  "lg-zoom-out",
  "lg-zoom-out-big",
  "lg-zoom-out-in",
  "lg-zoom-in-out",
  "lg-soft-zoom",
  "lg-scale-up",
  "lg-slide-circular",
  "lg-slide-circular-vertical",
  "lg-slide-vertical",
  "lg-slide-vertical-growth",
  "lg-slide-skew-only",
  "lg-slide-skew-only-rev",
  "lg-slide-skew-only-y",
  "lg-slide-skew-only-y-rev",
  "lg-slide-skew",
  "lg-slide-skew-rev",
  "lg-slide-skew-cross",
  "lg-slide-skew-cross-rev",
  "lg-slide-skew-ver",
  "lg-slide-skew-ver-rev",
  "lg-slide-skew-ver-cross",
  "lg-slide-skew-ver-cross-rev",
  "lg-lollipop",
  "lg-lollipop-rev",
  "lg-rotate",
  "lg-rotate-rev",
  "lg-tube"
];

function randomIntFromInterval(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

$galleryContainer.addEventListener("lgBeforeSlide", (event) => {
  const pluginInstance = event.detail.instance;
  const $outer = document.querySelector(".lg-outer");
  for (let index = 0; index < transitions.length; index++) {
    if ($outer.classList.contains(transitions[index])) {
      $outer.classList.remove(transitions[index]);
      const rndInt = randomIntFromInterval(0, transitions.length - 1);
      $outer.classList.add(transitions[rndInt]);
    }
  }
});

lightGallery($galleryContainer, {
  speed: 500,
  plugins: [lgZoom]
});
